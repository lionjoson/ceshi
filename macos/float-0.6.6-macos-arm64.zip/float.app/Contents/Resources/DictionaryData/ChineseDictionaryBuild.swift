import Foundation
import SQLite3

struct CEDICTEntry {
    let traditional: String
    let simplified: String
    let pronunciation: String
    let meanings: [String]
    let details: [String]
    var properName: Bool { pronunciation.first?.isUppercase == true }
}

@main
struct ChineseDictionaryBuild {
    static func main() throws {
        let input = URL(fileURLWithPath: CommandLine.arguments[1])
        let wikiURL = URL(fileURLWithPath: CommandLine.arguments[2])
        let output = URL(fileURLWithPath: CommandLine.arguments[3])
        let statsURL = URL(fileURLWithPath: CommandLine.arguments[4])
        try? FileManager.default.removeItem(at: output)
        let pattern = try NSRegularExpression(pattern: #"^(\S+)\s+(\S+)\s+\[+(.+?)\]+\s+/(.*)/$"#)
        var entries: [CEDICTEntry] = []
        var malformed: [String] = []
        var header: [String] = []
        try DictionaryLines.read(input, cancelled: { false }) { line in
            if line.hasPrefix("#") { header.append(line); return }
            if line.trimmingCharacters(in: .whitespaces).isEmpty { return }
            let ns = line as NSString
            guard let match = pattern.firstMatch(in: line, range: NSRange(location: 0, length: ns.length)) else { malformed.append(line); return }
            let parts = (1...4).map { ns.substring(with: match.range(at: $0)) }
            let senses = parts[3].split(separator: "/").map(String.init)
            let meanings = senses.filter { !$0.hasPrefix("CL:") }
            guard !meanings.isEmpty else { return }
            entries.append(CEDICTEntry(traditional: parts[0], simplified: parts[1], pronunciation: parts[2], meanings: meanings, details: senses.filter { $0.hasPrefix("CL:") }))
        }
        guard malformed.isEmpty, entries.count > 100_000 else { throw DictionaryFailure.message("CC-CEDICT 解析未通过：\(malformed.prefix(3))") }
        let index = try DictionaryIndex(url: output, create: true)
        var authoritative = Set<String>()
        var simplifiedWords = Set<String>()
        for proper in [false, true] {
            for entry in entries where entry.properName == proper {
                let normalizedTraditional = entry.traditional.applyingTransform(StringTransform("Traditional-Simplified"), reverse: false) ?? entry.traditional
                let aliases = [entry.traditional, normalizedTraditional]
                for key in [entry.simplified] + aliases { authoritative.insert(DictionaryLanguage.key(key)) }
                simplifiedWords.insert(DictionaryLanguage.key(entry.simplified))
                try index.add(DictionaryRecord(word: entry.simplified, pronunciation: entry.pronunciation,
                    partOfSpeech: entry.details.joined(separator: " · "), meanings: entry.meanings, examples: []), target: "en", aliases: aliases)
            }
        }
        var db: OpaquePointer?
        guard sqlite3_open_v2(wikiURL.path, &db, SQLITE_OPEN_READONLY, nil) == SQLITE_OK else { throw DictionaryFailure.message("WikDict 源库无法读取。") }
        defer { sqlite3_close(db) }
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(db, "SELECT written_rep,trans_list FROM simple_translation", -1, &statement, nil) == SQLITE_OK else { throw DictionaryFailure.message("WikDict 格式不正确。") }
        defer { sqlite3_finalize(statement) }
        var supplementary = 0
        while true {
            let status = sqlite3_step(statement)
            if status == SQLITE_DONE { break }
            guard status == SQLITE_ROW, let a = sqlite3_column_text(statement, 0), let b = sqlite3_column_text(statement, 1) else { throw DictionaryFailure.message("WikDict 读取未完成。") }
            let word = String(cString: a)
            let normalized = word.applyingTransform(StringTransform("Traditional-Simplified"), reverse: false) ?? word
            guard !authoritative.contains(DictionaryLanguage.key(normalized)), !authoritative.contains(DictionaryLanguage.key(word)) else { continue }
            let meanings = String(cString: b).components(separatedBy: " | ").filter { !$0.isEmpty }
            if !meanings.isEmpty {
                try index.add(DictionaryRecord(word: word, pronunciation: "", partOfSpeech: "", meanings: meanings, examples: []), target: "en", aliases: [normalized])
                simplifiedWords.insert(DictionaryLanguage.key(normalized)); supplementary += 1
            }
        }
        try index.finish()
        let stats: [String: Any] = ["cedictEntries":entries.count,"wikdictSupplementaryEntries":supplementary,"distinctSimplifiedWords":simplifiedWords.count,"queryForms":try index.recordCount(),"indexBytes":(try FileManager.default.attributesOfItem(atPath: output.path)[.size] as! NSNumber).int64Value,"malformedEntries":malformed.count,"sourceHeader":header]
        try JSONSerialization.data(withJSONObject: stats, options: [.prettyPrinted,.sortedKeys]).write(to: statsURL)
        print(String(data: try JSONSerialization.data(withJSONObject: stats.filter { $0.key != "sourceHeader" }), encoding: .utf8)!)
    }
}
