from pathlib import Path
import sqlite3,json,unicodedata,gzip,shutil,hashlib,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()
work=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else Path.cwd()/'reverse-packs'
work.mkdir(parents=True,exist_ok=True)
assets=work/'DictionaryData';assets.mkdir(parents=True,exist_ok=True);results=[]
for code in ['ar','ko','th','uk','hi','vi']:
 source=root/('kaikki-'+code+'.sqlite');dest=work/('kaikki-'+code+'-en.sqlite')
 dest.unlink(missing_ok=True)
 original=sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True);db=sqlite3.connect(dest)
 db.execute('create table entries(key text not null,value blob not null)')
 seen=set()
 for (blob,) in original.execute('select value from entries'):
  item=json.loads(blob)
  for translated in item['meanings']:
   translated=translated.strip()
   if not translated or len(translated)>200:continue
   token=(translated,item['word'])
   if token in seen:continue
   seen.add(token)
   record=dict(word=translated,pronunciation='',partOfSpeech='',meanings=[item['word']],examples=[])
   value=json.dumps(record,ensure_ascii=False).encode()
   key=unicodedata.normalize('NFC',translated).lower();keys={key}
   if code=='ar':keys.add(''.join(c for c in key if unicodedata.category(c)!='Mn'))
   if code=='uk':keys.add(key.replace('\u0301','').replace('\u0300',''))
   for key in keys:db.execute('insert into entries values (?,?)',(key,value))
 db.execute('create index words on entries(key)');db.execute('pragma user_version=1');db.commit()
 count=db.execute('select count(distinct key) from entries').fetchone()[0]
 db.close();original.close()
 target=assets/('kaikki-'+code+'-en.sqlite.gz')
 with dest.open('rb') as f,gzip.GzipFile(filename=str(target),mode='wb',mtime=0) as z:shutil.copyfileobj(f,z)
 results.append(dict(source=code,target='en',bytes=target.stat().st_size,sha512=hashlib.sha512(target.read_bytes()).hexdigest(),headwords=count,bundledFile=target.name,indexBytes=dest.stat().st_size))
 print(code,count,target.stat().st_size,flush=True)
(work/'reverse-packs.json').write_text(json.dumps(results,indent=2))
