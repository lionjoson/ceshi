from pathlib import Path
import subprocess,json,sqlite3,time,hashlib,gzip,shutil,sys
root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path.cwd()/'kaikki-packs'
root.mkdir(parents=True,exist_ok=True)
assets=root/'DictionaryData';assets.mkdir(parents=True,exist_ok=True)
source='https://kaikki.org/dictionary/English/kaikki.org-dictionary-English.jsonl'
langs=['ar','ko','th','uk','hi','vi'];con={}
for code in langs:
 p=root/('kaikki-'+code+'.sqlite');p.unlink(missing_ok=True)
 c=sqlite3.connect(p);c.execute('create table entries(key text not null,value blob not null)');con[code]=c
process=subprocess.Popen(['curl','-sSL','--fail','--max-time','1800',source],stdout=subprocess.PIPE,stderr=open(root/'kaikki-download.log','w'))
count=0;bytecount=0;last=0;started=time.time()
try:
 for line in process.stdout:
  bytecount+=len(line);count+=1
  if bytecount-last>100_000_000:
   print('Kaikki source',round(bytecount/1e6),'MB; elapsed',round(time.time()-started),'s;',dict((k,con[k].total_changes) for k in langs),flush=True);last=bytecount
  data=json.loads(line)
  if data.get('lang_code')!='en':continue
  word=data.get('word','').strip()
  if not word or len(word)>200:continue
  translations=list(data.get('translations',[]))
  for sense in data.get('senses',[]):translations.extend(sense.get('translations',[]))
  meanings={}
  for entry in translations:
   code=entry.get('code');value=entry.get('word','').strip()
   if code in con and value and len(value)<1000:meanings.setdefault(code,[]).append(value)
  pron=next((x.get('ipa') for x in data.get('sounds',[]) if x.get('ipa')),'')
  for code,words in meanings.items():
   record=dict(word=word,pronunciation=pron,partOfSpeech=data.get('pos',''),meanings=list(dict.fromkeys(words)),examples=[])
   con[code].execute('insert into entries values (?,?)',(word.lower(),json.dumps(record,ensure_ascii=False).encode()))
 code=process.wait()
 if code:raise RuntimeError('curl failed '+str(code))
 results=[]
 for code,c in con.items():
  c.execute('create index words on entries(key)');c.execute('pragma user_version=1');c.commit()
  entries=c.execute('select count(distinct key) from entries').fetchone()[0];c.close()
  p=root/('kaikki-'+code+'.sqlite');out=assets/('kaikki-en-'+code+'.sqlite.gz')
  with p.open('rb') as f,gzip.GzipFile(filename=str(out),mode='wb',mtime=0) as z:shutil.copyfileobj(f,z)
  results.append(dict(code=code,words=entries,bytes=out.stat().st_size,sha512=hashlib.sha512(out.read_bytes()).hexdigest(),file=out.name))
 (root/'kaikki-packs.json').write_text(json.dumps(results,indent=2))
 print('FINISHED',results,flush=True)
except BaseException:
 process.terminate()
 for c in con.values():
  try:c.close()
  except:pass
 raise
