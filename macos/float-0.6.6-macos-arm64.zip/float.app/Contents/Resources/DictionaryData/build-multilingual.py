"""Build a sense-preserving multilingual supplement from official Kaikki JSONL.
Only explicitly identified English translation groups are joined. A cross-language
result is a sense-linked suggestion, not a new verified direct dictionary entry.
No examples, audio, quotations, etymologies or personal data are copied.
"""
import json,sqlite3,unicodedata as u,re,sys,time,gzip,hashlib
from pathlib import Path
langs={'ar','pl','de','ru','fr','zh','ko','nl','pt','ja','th','tr','uk','es','it','hi','id','en','vi'}
def key(w,lang):
 w=u.normalize('NFC',w.strip())
 if lang=='tr':w=w.replace('I','ı').replace('İ','i')
 w=w.lower().replace('’',"'")
 if lang in ('ru','uk'):w=w.replace('\u0301','').replace('\u0341','')
 if lang=='ar':w=''.join(c for c in w if not (0x064b<=ord(c)<=0x065f or ord(c) in (0x0670,0x0640)))
 if lang=='fr':w=w.replace('œ','oe').replace('æ','ae')
 return w
source=Path(sys.argv[1]); dest=Path(sys.argv[2]);dest.unlink(missing_ok=True)
c=sqlite3.connect(dest);c.executescript('pragma journal_mode=off; pragma synchronous=off; pragma cache_size=-16000; create table senses(id integer primary key, headword text not null,pos text not null,gloss text not null); create table terms(sense integer not null, lang text not null,word text not null,key text not null,pron text not null,tags text not null,alias integer not null);')
c.execute('begin');n=0;bytesread=0;started=time.time();sid=0;last=0;recovered=0
excluded={'archaic','obsolete','rare','dated','historical','nonstandard'}
with source.open('rb') as f:
 for line in f:
  bytesread+=len(line);n+=1;d=json.loads(line)
  if d.get('lang_code')!='en':continue
  word=d.get('word','').strip()
  if not word or len(word)>200:continue
  groups={}
  translations=list(d.get('translations',[]))
  for s in d.get('senses',[]):translations+=s.get('translations',[])
  for t in translations:
   lang=t.get('code');lang='zh' if lang=='cmn' else lang
   v=t.get('word','').strip();sense=t.get('sense','').strip();tags=t.get('tags',[])
   if not v and lang=='zh':
    match=re.match(r'^([\u3400-\u9fff]+\s*[/／]\s*[\u3400-\u9fff]+)\s*\(',t.get('note',''))
    if match:v=match.group(1);recovered+=1
   if lang not in langs or lang=='en' or not v or len(v)>200 or not sense or len(sense)>2000 or excluded.intersection(tags):continue
   if lang=='zh' and (set(tags)&{'Hokkien','Cantonese','Dungan','Hakka','Wu','Min-Nan','Teochew'}):continue
   if lang=='ar' and any(x.endswith('-Arabic') and x not in ('Modern-Standard-Arabic','Standard-Arabic') for x in tags):continue
   for variant in (re.split(r'\s*[/／]\s*',v) if lang=='zh' else [v]):
    if not variant or variant in ('-','—'):continue
    groups.setdefault(sense,{})[(lang,variant)]=(t.get('roman',''),', '.join(tags))
  pron=next((s['ipa'] for s in d.get('sounds',[]) if 'ipa' in s),'')
  aliases=[]
  for form in d.get('forms',[]):
   v=form.get('form','').strip();tags=form.get('tags',[])
   if v and len(v)<=200 and v!=word and not excluded.intersection(tags):aliases.append(v)
  for sense,terms in groups.items():
   if not terms:continue
   sid+=1;c.execute('insert into senses values(?,?,?,?)',(sid,word,d.get('pos',''),sense))
   rows=[(sid,'en',word,key(word,'en'),pron,'',0)]
   rows += [(sid,'en',a,key(a,'en'),pron,'',1) for a in dict.fromkeys(aliases)]
   rows += [(sid,lang,v,key(v,lang),roman,tags,0) for (lang,v),(roman,tags) in terms.items()]
   c.executemany('insert into terms values(?,?,?,?,?,?,?)',rows)
  if bytesread-last>200_000_000:
   c.commit();c.execute('begin');print('processed',round(bytesread/1e6),'MB',n,'entries',sid,'sense groups',round(time.time()-started),'seconds',flush=True);last=bytesread
c.commit();print('indexing',flush=True)
c.executescript('create index lookup on terms(lang,key,sense);create index targets on terms(sense,lang,alias);pragma user_version=1;')
stats={'recoveredExplicitChineseNoteTerms':recovered,'inputBytes':bytesread,'inputEntries':n,'senseGroups':sid,'termRows':c.execute('select count(*) from terms').fetchone()[0],'languages':{l:{'words':cnt,'forms':forms} for l,cnt,forms in c.execute('select lang,count(distinct case when alias=0 then key end),count(distinct key) from terms group by lang')},'indexBytes':dest.stat().st_size}
c.close();Path('multilingual-stats.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2));print(json.dumps(stats,ensure_ascii=False),flush=True)
